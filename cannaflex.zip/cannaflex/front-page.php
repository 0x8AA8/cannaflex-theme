<?php
/**
 * Template: Front Page (Home)
 *
 * Matches: CANNAFLEX WEBSITE Home page.pdf
 *
 * @package Cannaflex
 */

get_header();
?>

<!-- ===== 1. SPLIT HERO ===== -->
<section class="hero-split" aria-labelledby="hero-heading">
    <div class="hero-split__content">
        <div class="hero-split__inner">
            <h1 id="hero-heading"><?php echo esc_html(cannaflex_get('hero_heading', 'We are Leading the Change')); ?></h1>
            <?php echo wp_kses_post(wpautop(esc_html(cannaflex_get('hero_text', "We're redefining what cannabis can do. From Morocco's ancestral fields to international markets — we advance the legacy of Moroccan cannabis tradition, innovation, and craftsmanship to deliver premium, sustainable and high-quality cannabis products.\n\nJoin us in shaping the future of responsible, sustainable, and high-quality cannabis.")))); ?>
            <a href="<?php echo esc_url(cannaflex_get('hero_btn_url', '/contact')); ?>" class="btn btn--primary">
                <?php echo esc_html(cannaflex_get('hero_btn_text', 'Join Us')); ?>
            </a>
        </div>
    </div>
    <div class="hero-split__image">
        <?php
        $hero_img = cannaflex_get('hero_image');
        if ($hero_img) : ?>
            <img src="<?php echo esc_url($hero_img); ?>" alt="" loading="eager" fetchpriority="high">
        <?php else : ?>
            <div class="placeholder-img placeholder-img--full"><?php esc_html_e('Hero Image', 'cannaflex'); ?></div>
        <?php endif; ?>
    </div>
</section>

<!-- ===== 2. ABOUT (PDF: left photo panel with centered badge overlay + right content) ===== -->
<section class="home-about-split" aria-labelledby="home-about-heading">
    <div class="home-about-split__media">
        <?php $about_photo = cannaflex_get('home_about_photo'); ?>
        <?php if ($about_photo) : ?>
            <img src="<?php echo esc_url($about_photo); ?>" alt="" loading="lazy" class="home-about-split__photo">
        <?php else : ?>
            <div class="placeholder-img home-about-split__photo"><?php esc_html_e('Background Photo', 'cannaflex'); ?></div>
        <?php endif; ?>

        <div class="home-about-split__badge">
            <?php
            $about_badge = cannaflex_get('home_about_image');
            if ($about_badge) : ?>
                <img src="<?php echo esc_url($about_badge); ?>" alt="<?php esc_attr_e('Made in Morocco', 'cannaflex'); ?>" loading="lazy" class="home-about-split__badge-img">
            <?php else : ?>
                <svg class="home-about-split__badge-svg" viewBox="0 0 150 150" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <circle cx="75" cy="75" r="70" fill="none" stroke="currentColor" stroke-width="2"/>
                    <circle cx="75" cy="75" r="60" fill="none" stroke="currentColor" stroke-width="1"/>
                    <text fill="currentColor" font-family="Inter,sans-serif" font-size="10" font-weight="700" text-anchor="middle">
                        <textPath href="#home-badge-c" startOffset="50%">MADE IN MOROCCO</textPath>
                    </text>
                    <defs><path id="home-badge-c" d="M 75,15 a 60,60 0 1,1 0,120 a 60,60 0 1,1 0,-120"/></defs>
                    <text x="75" y="82" fill="currentColor" font-family="Inter,sans-serif" font-size="22" font-weight="700" text-anchor="middle">&#x1F33F;</text>
                </svg>
            <?php endif; ?>
        </div>
    </div>
    <div class="home-about-split__content">
        <h2 id="home-about-heading"><?php echo esc_html(cannaflex_get('home_about_heading', 'About Us')); ?></h2>
        <p class="home-about-split__intro"><?php echo esc_html(cannaflex_get('home_about_intro', "From the ancestral cradle of Moroccan cannabis to the global market \u{2014} we're the partner you can trust.")); ?></p>
        <?php echo wp_kses_post(wpautop(esc_html(cannaflex_get('home_about_text', "At the heart of the Rif Mountains \u{2014} the ancestral cradle of Moroccan cannabis. This region's rich soil, unique microclimate, and deep cultural legacy have made it one of the world's most iconic cannabis-growing regions.\n\nWe honor that heritage by cultivating each plant with care and harvesting it with respect, using time-honored traditions passed down through generations of Moroccan farmers.\n\nMore than a producer, we're your global growth partner. Cannaflex's robust international network offers scalable, compliant cannabis solutions delivered to your market.")))); ?>
        <a href="<?php echo esc_url(home_url('/about/')); ?>" class="btn btn--primary">
            <?php echo esc_html(cannaflex_get('home_about_btn', 'Learn More')); ?>
        </a>
    </div>
</section>

<!-- ===== 3. SEED FLOW (PDF: intro card top-left, agriculture top-right, image bottom-left, transformation+export bottom-right) ===== -->
<?php
$tiles = [
    ['title' => 'Agriculture',                 'text' => 'We partner with agricultural cooperatives authorized by Morocco\'s National Cannabis Agency (ANRAC) to cultivate cannabis in full compliance with Moroccan regulations.', 'icon' => 'leaf'],
    ['title' => 'Transformation',              'text' => 'We transform and process cannabis into high-quality products, ensuring all certifications and standards are met throughout the production chain.', 'icon' => 'cycle'],
    ['title' => 'Commercialisation and Export', 'text' => 'We sell and distribute our products locally and internationally in strict compliance to current Moroccan regulations, ensuring quality and compliance across all markets.', 'icon' => 'globe'],
];

$icons = [
    'leaf'  => '<svg viewBox="0 0 24 24" stroke-width="2"><path d="M17 8c.7-1 1-2 1-3 0-3.4-3.6-5-8-5C5.6 0 2 1.6 2 5c0 1 .3 2 1 3-1.6 1.5-3 4-3 7 0 5 4 9 9 9h2c5 0 9-4 9-9 0-3-1.4-5.5-3-7z" stroke="currentColor" fill="none"/></svg>',
    'cycle' => '<svg viewBox="0 0 24 24" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.2-8.6" stroke="currentColor" fill="none"/><path d="M21 3v6h-6" stroke="currentColor" fill="none"/></svg>',
    'globe' => '<svg viewBox="0 0 24 24" stroke-width="2"><circle cx="12" cy="12" r="10" stroke="currentColor" fill="none"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10A15.3 15.3 0 0 1 12 2z" stroke="currentColor" fill="none"/></svg>',
];
?>
<section class="seed-flow section" aria-labelledby="seed-heading">
    <div class="container">
        <div class="seed-flow__grid">
            <!-- Top-left: intro text card -->
            <article class="seed-flow__card seed-flow__card--intro">
                <?php $seed_img = cannaflex_get('seed_image');
                if ($seed_img) : ?>
                    <img src="<?php echo esc_url($seed_img); ?>" alt="" loading="lazy" class="seed-flow__card-bg">
                <?php endif; ?>
                <div class="seed-flow__card-inner">
                    <h2 id="seed-heading"><?php echo esc_html(cannaflex_get('seed_heading', 'From Seed to Shelf')); ?></h2>
                    <p><?php echo esc_html(cannaflex_get('seed_text', 'We control every step of the cannabis value chain — from cultivation in the Rif Mountains to finished products ready for global markets. This guarantees consistency, traceability, and outstanding quality across our full range of cannabis products.')); ?></p>
                    <a href="<?php echo esc_url(home_url('/activity/')); ?>" class="btn btn--primary"><?php esc_html_e('Learn More', 'cannaflex'); ?></a>
                </div>
            </article>

            <!-- Top-right: Agriculture -->
            <?php $t = cannaflex_get('process_1_title', $tiles[0]['title']); $d = cannaflex_get('process_1_text', $tiles[0]['text']); ?>
            <article class="seed-flow__card seed-flow__card--icon">
                <div class="seed-flow__icon"><?php echo $icons['leaf']; // phpcs:ignore ?></div>
                <h3><?php echo esc_html($t); ?></h3>
                <p><?php echo esc_html($d); ?></p>
            </article>

            <!-- Bottom-left: large image -->
            <article class="seed-flow__media">
                <?php if ($seed_img) : ?>
                    <img src="<?php echo esc_url($seed_img); ?>" alt="" loading="lazy">
                <?php else : ?>
                    <div class="placeholder-img placeholder-img--full"><?php esc_html_e('Image', 'cannaflex'); ?></div>
                <?php endif; ?>
            </article>

            <!-- Bottom-right: Transformation -->
            <?php $t = cannaflex_get('process_2_title', $tiles[1]['title']); $d = cannaflex_get('process_2_text', $tiles[1]['text']); ?>
            <article class="seed-flow__card seed-flow__card--icon">
                <div class="seed-flow__icon"><?php echo $icons['cycle']; // phpcs:ignore ?></div>
                <h3><?php echo esc_html($t); ?></h3>
                <p><?php echo esc_html($d); ?></p>
            </article>

            <!-- Bottom-right-2: Commercialisation -->
            <?php $t = cannaflex_get('process_3_title', $tiles[2]['title']); $d = cannaflex_get('process_3_text', $tiles[2]['text']); ?>
            <article class="seed-flow__card seed-flow__card--icon">
                <div class="seed-flow__icon"><?php echo $icons['globe']; // phpcs:ignore ?></div>
                <h3><?php echo esc_html($t); ?></h3>
                <p><?php echo esc_html($d); ?></p>
            </article>
        </div>
    </div>
</section>

<!-- ===== 4. OUR PRODUCTS ===== -->
<section class="products-section section" aria-labelledby="products-heading">
    <div class="container">
        <h2 id="products-heading"><?php echo esc_html(cannaflex_get('products_heading', 'Our Products')); ?></h2>
        <p class="section-subtitle"><?php echo esc_html(cannaflex_get('products_text', 'We offer a comprehensive range of premium cannabis products, from dermatological to medical that not only meet manufacturing standards, but also comply with local and international regulations. Each product embodies the legacy of Moroccan craftsmanship — a refined blend of traditional know-how that reflects our unwavering commitment to authenticity, quality, and the healing power of Moroccan cannabis.')); ?></p>

        <div class="products-slider" aria-label="<?php esc_attr_e('Product categories', 'cannaflex'); ?>">
            <div class="products-slider__track" id="products-track">
                <?php
                $products = get_posts(['post_type' => 'cfx_product', 'posts_per_page' => 12, 'orderby' => 'menu_order', 'order' => 'ASC']);
                if ($products) :
                    foreach ($products as $prod) :
                        $thumb = get_the_post_thumbnail_url($prod, 'card'); ?>
                        <article class="product-card">
                            <div class="product-card__image">
                                <?php if ($thumb) : ?><img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($prod->post_title); ?>" loading="lazy">
                                <?php else : ?><div class="placeholder-img placeholder-img--full"><?php echo esc_html($prod->post_title); ?></div><?php endif; ?>
                            </div>
                            <div class="product-card__label">
                                <h3><?php echo esc_html($prod->post_title); ?></h3>
                                <p><?php echo esc_html(wp_trim_words($prod->post_excerpt ?: $prod->post_content, 12)); ?></p>
                                <a href="<?php echo esc_url(get_permalink($prod)); ?>"><?php esc_html_e('Read More', 'cannaflex'); ?></a>
                            </div>
                        </article>
                    <?php endforeach;
                else :
                    foreach (['Cosmetics', 'Supplements', 'Edibles', 'Extracts', 'Vapes', 'Pet Care'] as $name) : ?>
                        <article class="product-card">
                            <div class="product-card__image"><div class="placeholder-img placeholder-img--full"><?php echo esc_html($name); ?></div></div>
                            <div class="product-card__label">
                                <h3><?php echo esc_html($name); ?></h3>
                                <a href="<?php echo esc_url(home_url('/products/')); ?>"><?php esc_html_e('Read More', 'cannaflex'); ?></a>
                            </div>
                        </article>
                    <?php endforeach;
                endif;
                wp_reset_postdata(); ?>
            </div>
            <div class="slider-controls">
                <button type="button" class="slider-btn" id="slider-prev" aria-label="<?php esc_attr_e('Previous', 'cannaflex'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M15 19l-7-7 7-7"/></svg></button>
                <div class="slider-dots" id="slider-dots"></div>
                <button type="button" class="slider-btn" id="slider-next" aria-label="<?php esc_attr_e('Next', 'cannaflex'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg></button>
            </div>
        </div>
    </div>
</section>

<!-- ===== 5. BRANDS STRIP ===== -->
<section class="brands-strip section" aria-labelledby="brands-heading">
    <div class="container">
        <h2 id="brands-heading"><?php echo esc_html(cannaflex_get('brands_heading', 'Discover our Brands')); ?></h2>
        <p><?php echo esc_html(cannaflex_get('brands_text', 'Explore our distinct brands, each with its own identity, unified by the values at the heart of our company.')); ?></p>
        <div class="brands-grid">
            <?php
            $brands = get_posts(['post_type' => 'cfx_brand', 'posts_per_page' => 10, 'orderby' => 'menu_order', 'order' => 'ASC']);
            if ($brands) :
                foreach ($brands as $brand) :
                    $logo = get_the_post_thumbnail_url($brand, 'medium');
                    if ($logo) : ?><img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($brand->post_title); ?>" loading="lazy" height="48"><?php endif;
                endforeach;
            else :
                foreach (['VAPOCAN', 'FITOBOTANIKA', 'RifGold'] as $b) : ?>
                    <span class="brands-grid__placeholder"><?php echo esc_html($b); ?></span>
                <?php endforeach;
            endif;
            wp_reset_postdata(); ?>
        </div>
    </div>
</section>

<!-- ===== 6. RECENT NEWS (horizontal timeline with top/bottom cards) ===== -->
<section class="news-timeline section" aria-labelledby="news-heading">
    <div class="container">
        <h2 id="news-heading"><?php esc_html_e('Recent News', 'cannaflex'); ?></h2>
        <p class="section-subtitle news-timeline__sub"><?php esc_html_e('Stay connected to discover how we\'re driving change in the global cannabis space and beyond through all of time.', 'cannaflex'); ?></p>

        <div class="timeline-h">
            <div class="timeline-h__axis"></div>
            <?php
            $news = get_posts(['post_type' => 'post', 'posts_per_page' => 6, 'category_name' => 'news']);
            if ($news) :
                foreach ($news as $idx => $item) :
                    $year      = get_the_date('Y', $item);
                    $day_month = get_the_date('d F', $item);
                    $pos       = ($idx % 2 === 0) ? 'top' : 'bottom'; ?>
                    <article class="timeline-h__item timeline-h__item--<?php echo esc_attr($pos); ?>">
                        <div class="timeline-h__dot"></div>
                        <div class="timeline-h__card">
                            <span class="timeline-h__year"><?php echo esc_html($year); ?></span>
                            <span class="timeline-h__date"><?php echo esc_html($day_month); ?></span>
                            <h3><?php echo esc_html($item->post_title); ?></h3>
                            <p><?php echo esc_html(wp_trim_words($item->post_content, 15)); ?></p>
                            <a href="<?php echo esc_url(get_permalink($item)); ?>"><?php esc_html_e('Read More', 'cannaflex'); ?></a>
                        </div>
                    </article>
                <?php endforeach;
            else : ?>
                <article class="timeline-h__item timeline-h__item--top">
                    <div class="timeline-h__dot"></div>
                    <div class="timeline-h__card">
                        <span class="timeline-h__year">2025</span>
                        <span class="timeline-h__date">04 April</span>
                        <h3><?php esc_html_e('New CBD Skincare Line Launching Soon', 'cannaflex'); ?></h3>
                        <p><?php esc_html_e('Join us at the forefront as we bring the future of cannabis in Africa — together.', 'cannaflex'); ?></p>
                        <a href="#"><?php esc_html_e('Read More', 'cannaflex'); ?></a>
                    </div>
                </article>
                <article class="timeline-h__item timeline-h__item--bottom">
                    <div class="timeline-h__dot"></div>
                    <div class="timeline-h__card">
                        <span class="timeline-h__year">2025</span>
                        <span class="timeline-h__date">07 June</span>
                        <h3><?php esc_html_e('Cannaflex at Africa CannaTech Expo 2025', 'cannaflex'); ?></h3>
                        <p><?php esc_html_e("Africa's premier cannabis technology event. Let's shape the future of cannabis in Africa — together.", 'cannaflex'); ?></p>
                        <a href="#"><?php esc_html_e('Read More', 'cannaflex'); ?></a>
                    </div>
                </article>
            <?php endif;
            wp_reset_postdata(); ?>
        </div>
    </div>
</section>

<!-- ===== 7. RECENT POSTS ===== -->
<section class="recent-posts section" aria-labelledby="posts-heading">
    <div class="container">
        <h2 id="posts-heading"><?php esc_html_e('Recent Posts', 'cannaflex'); ?></h2>
        <div class="recent-posts__grid">
            <div class="recent-posts__list">
                <?php
                $posts = get_posts(['post_type' => 'post', 'posts_per_page' => 4]);
                if ($posts) :
                    foreach ($posts as $p) :
                        $thumb = get_the_post_thumbnail_url($p, 'thumb-sm'); ?>
                        <article class="post-card">
                            <div class="post-card__thumb">
                                <?php if ($thumb) : ?><img src="<?php echo esc_url($thumb); ?>" alt="" loading="lazy" width="100" height="80">
                                <?php else : ?><div class="placeholder-img placeholder-img--thumb"></div><?php endif; ?>
                            </div>
                            <div>
                                <h3><?php echo esc_html($p->post_title); ?></h3>
                                <p><?php echo esc_html(wp_trim_words($p->post_content, 12)); ?></p>
                                <a href="<?php echo esc_url(get_permalink($p)); ?>"><?php esc_html_e('Read All', 'cannaflex'); ?></a>
                            </div>
                        </article>
                    <?php endforeach;
                else : ?>
                    <article class="post-card">
                        <div class="post-card__thumb"><div class="placeholder-img placeholder-img--thumb"></div></div>
                        <div><h3><?php esc_html_e('Cannaflex Expands Distribution Across Europe', 'cannaflex'); ?></h3><p><?php esc_html_e('New partnerships bring premium Moroccan cannabis products to more markets.', 'cannaflex'); ?></p><a href="#"><?php esc_html_e('Read All', 'cannaflex'); ?></a></div>
                    </article>
                    <article class="post-card">
                        <div class="post-card__thumb"><div class="placeholder-img placeholder-img--thumb"></div></div>
                        <div><h3><?php esc_html_e('Sustainability Update: Zero-Waste Farming Pilot in the Rif', 'cannaflex'); ?></h3><p><?php esc_html_e('Our pilot program recycles 100% of plant waste into organic compost.', 'cannaflex'); ?></p><a href="#"><?php esc_html_e('Read All', 'cannaflex'); ?></a></div>
                    </article>
                <?php endif;
                wp_reset_postdata(); ?>
            </div>
            <div class="recent-posts__featured">
                <?php if ($posts && get_the_post_thumbnail_url($posts[0], 'hero')) : ?>
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url($posts[0], 'hero')); ?>" alt="" loading="lazy">
                <?php else : ?>
                    <div class="placeholder-img placeholder-img--featured"><?php esc_html_e('Featured Image', 'cannaflex'); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- ===== 8. CONTACT SPLIT ===== -->
<section class="home-contact" aria-labelledby="home-contact-heading">
    <div class="home-contact__info">
        <?php $contact_bg = cannaflex_get('home_contact_image');
        if ($contact_bg) : ?>
            <div class="home-contact__info-bg"><img src="<?php echo esc_url($contact_bg); ?>" alt="" loading="lazy"></div>
        <?php endif; ?>
        <div class="home-contact__info-text">
            <?php echo wp_kses_post(nl2br(cannaflex_get('home_contact_text', "Have a question, an inquiry, or need more information about our products and services?\n\nFill out the form or call us at +212 537 327 822 — Our team will be happy to assist you."))); ?>
        </div>
    </div>
    <div class="home-contact__form">
        <h2 id="home-contact-heading"><?php esc_html_e("Let's Connect", 'cannaflex'); ?></h2>
        <?php get_template_part('template-parts/contact', 'form'); ?>
    </div>
</section>

<?php get_footer(); ?>
